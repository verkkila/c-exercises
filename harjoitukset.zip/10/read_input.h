#define BUF_SIZE 64

void read_int(const char *prompt, int *val);
void read_uint(const char *prompt, unsigned int *val);
void read_float(const char *prompt, float *val);
void read_double(const char *prompt, double *val);
