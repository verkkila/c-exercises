#include <stdio.h>
#include <stdlib.h>

int main(void)
{
        printf("Terve ohjelmoija! Olet suorittanut main.c -ohjelman.\n");
        return EXIT_SUCCESS;
}
